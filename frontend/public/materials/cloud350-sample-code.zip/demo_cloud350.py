# Ma nguon mau mon CLOUD350: Dien toan Dam may
# Huong dan sinh vien thuc hanh
print('Chay thanh cong chuong trinh mau mon CLOUD350')
