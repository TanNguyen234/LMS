Huong dan su dung tai lieu demo_cs101.py
Dai hoc - He thong LMS.