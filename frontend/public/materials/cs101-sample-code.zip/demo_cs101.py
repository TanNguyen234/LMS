# Ma nguon mau mon CS101: Nhap mon Lap trinh
# Huong dan sinh vien thuc hanh
print('Chay thanh cong chuong trinh mau mon CS101')
