# Ma nguon mau mon CS202: Cau truc du lieu va Giai thuat
# Huong dan sinh vien thuc hanh
print('Chay thanh cong chuong trinh mau mon CS202')
