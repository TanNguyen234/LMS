# Ma nguon mau mon DB201: Co so du lieu
# Huong dan sinh vien thuc hanh
print('Chay thanh cong chuong trinh mau mon DB201')
