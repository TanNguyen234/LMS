# Ma nguon mau mon NW210: Mang may tinh
# Huong dan sinh vien thuc hanh
print('Chay thanh cong chuong trinh mau mon NW210')
