# Ma nguon mau mon OS301: He dieu hanh
# Huong dan sinh vien thuc hanh
print('Chay thanh cong chuong trinh mau mon OS301')
