# Ma nguon mau mon PM401: Quan ly Du an CNTT
# Huong dan sinh vien thuc hanh
print('Chay thanh cong chuong trinh mau mon PM401')
