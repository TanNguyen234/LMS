# Ma nguon mau mon SE301: Cong nghe phan mem
# Huong dan sinh vien thuc hanh
print('Chay thanh cong chuong trinh mau mon SE301')
