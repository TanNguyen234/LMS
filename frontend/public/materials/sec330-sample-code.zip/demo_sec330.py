# Ma nguon mau mon SEC330: An toan Thong tin
# Huong dan sinh vien thuc hanh
print('Chay thanh cong chuong trinh mau mon SEC330')
