# Ma nguon mau mon WEB220: Phat trien Ung dung Web
# Huong dan sinh vien thuc hanh
print('Chay thanh cong chuong trinh mau mon WEB220')
