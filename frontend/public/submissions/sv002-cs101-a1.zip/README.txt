Huong dan chay chuong trinh sinh vien.
