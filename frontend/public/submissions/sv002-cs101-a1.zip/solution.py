# Ma nguon bai lam thuc hanh sinh vien
print('Chuong trinh da chay thanh cong!')
